import React, { useEffect, useState } from 'react';
import "../index.css"
import useGlobalUser from "../../../context/user/user.context";
import { useMatch } from '../../../api/match/match';

export function Scoreboard() {
    const [scores, setScores] = useState([])
    const [user, setUser] = useGlobalUser();
    const { scoreboard } = useMatch();

    useEffect(() => {
        async function GetScore() {
            const response = await scoreboard();
        }
        GetScore();
    }, [])


    return (
        <div className='scoreboard-container' >
            <div>
                {user} :  {scoreboard.playerWin || 0}
            </div>
            <div>
                Empates :  {scoreboard.tie || 0}
            </div>
            <div>
                I.A. :  {scoreboard.playerLoss || 0}
            </div>
        </div>
    );
}
